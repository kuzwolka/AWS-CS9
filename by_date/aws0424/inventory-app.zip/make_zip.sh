# Run from inventory-app directory
rm ../inventory-app.zip
zip -r ../inventory-app.zip *
